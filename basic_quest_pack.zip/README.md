# BasicVillagerQuests

This is a datapack for the mod [VillagerQuests](https://www.curseforge.com/minecraft/mc-mods/villagerquests) and contains some basic quests for it.
